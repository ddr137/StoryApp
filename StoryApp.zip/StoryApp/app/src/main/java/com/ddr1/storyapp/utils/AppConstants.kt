package com.ddr1.storyapp.utils

object AppConstants {
    const val TIME_OUT = 60.toLong()
    const val EXTRA_DETAIL = "EXTRA_DETAIL"
    const val DATABASE_FILE_NAME = "story_app.db"
}