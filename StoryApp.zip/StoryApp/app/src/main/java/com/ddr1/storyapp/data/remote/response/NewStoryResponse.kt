package com.ddr1.storyapp.data.remote.response

data class NewStoryResponse(
    val error: Boolean,
    val message: String
)